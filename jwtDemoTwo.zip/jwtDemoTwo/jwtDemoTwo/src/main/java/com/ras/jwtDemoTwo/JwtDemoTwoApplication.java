package com.ras.jwtDemoTwo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtDemoTwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtDemoTwoApplication.class, args);
	}

}
