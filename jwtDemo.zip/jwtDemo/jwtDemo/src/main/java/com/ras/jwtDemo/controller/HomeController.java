package com.ras.jwtDemo.controller;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {


    @GetMapping("/")
    public String home(HttpServletRequest request) {

        return "Welcome RASHI!!" + request.getSession().getId();
    }

    @PreAuthorize("hasRole('USER')")
    @GetMapping("/user")
    public String userEndPoint(HttpServletRequest request) {

        return "Welcome USER!!" + request.getSession().getId();
    }
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/admin")
    public String adminEndPoint(HttpServletRequest request) {

        return "Welcome ADMIN!!" + request.getSession().getId();
    }


}
